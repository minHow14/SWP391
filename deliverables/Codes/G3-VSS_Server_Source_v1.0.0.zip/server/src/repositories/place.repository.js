// d:/Projects/FPT/SWP391/server/src/repositories/place.repository.js
import { Prisma } from '@prisma/client';
import prisma from '../config/prisma.js';
import { isVegetarianPlace } from '../utils/vegetarianFilter.js';

export const placeRepository = {
  replaceImageUrls(records, db = prisma) {
    if (!records.length) return Promise.resolve([]);
    const rows = Prisma.join(records.map((record) => Prisma.sql`
      (${record.restaurantId}::integer, ${record.placeId}::text,
       ${record.previousImageUrl}::text, ${record.imageUrl}::text)`));
    return db.$queryRaw`
      UPDATE restaurants AS restaurant SET image_url = image.image_url, updated_at = NOW()
      FROM (VALUES ${rows}) AS image(restaurant_id, place_id, previous_image_url, image_url)
      WHERE restaurant.restaurant_id = image.restaurant_id AND restaurant.place_id = image.place_id
        AND restaurant.image_url IS NOT DISTINCT FROM image.previous_image_url
      RETURNING restaurant.restaurant_id`;
  },
  /**
   * Truy vấn danh sách nhà hàng lân cận ứng dụng Bounding Box và lọc theo chế độ ăn trên PostgreSQL
   */
  async findNearbyCandidates(
    { lat, lng, radiusKm, dietTypeId, status = 'APPROVED' } = {},
    db = prisma
  ) {
    const where = {
      latitude: { not: null },
      longitude: { not: null },
    };

    if (status) {
      where.status = status;
    }

    if (dietTypeId !== undefined && dietTypeId !== null) {
      where.diet_type_id = Number(dietTypeId);
    }

    if (lat !== undefined && lng !== undefined && radiusKm !== undefined) {
      const deltaLat = radiusKm / 111.0;
      const cosLat = Math.cos((Number(lat) * Math.PI) / 180.0);
      const deltaLng = radiusKm / (111.0 * (Math.abs(cosLat) > 0.001 ? Math.abs(cosLat) : 1));

      where.latitude = {
        gte: Number(lat) - deltaLat,
        lte: Number(lat) + deltaLat,
      };
      where.longitude = {
        gte: Number(lng) - deltaLng,
        lte: Number(lng) + deltaLng,
      };
    }

    return db.restaurant.findMany({
      where,
      include: {
        diet_type: true,
        details: true,
        restaurant_recipes: {
          include: {
            recipe: true,
          },
        },
      },
    });
  },

  /**
   * Cơ chế Cache-through (Read-through): Tự động lưu các quán chay thực tế lấy từ ZIOMAP vào PostgreSQL
   * Giúp hệ thống tự làm giàu dữ liệu, tiết kiệm tối đa credit API và tăng tốc độ truy vấn lần sau.
   */
  async saveExternalPlaces(places = [], db = prisma) {
    if (!Array.isArray(places) || places.length === 0) return [];
    const saved = [];
    for (const p of places) {
      if (!p.place_id || p.latitude == null || p.longitude == null || !isVegetarianPlace(p)) continue;
      try {
        const record = await db.restaurant.upsert({
          where: { place_id: p.place_id },
          update: {
            rating: p.rating != null ? Number(p.rating) : undefined,
            address: p.address || undefined,
            image_url: p.image_url || undefined,
          },
          create: {
            name: p.name,
            address: p.address,
            latitude: p.latitude,
            longitude: p.longitude,
            rating: p.rating != null ? Number(p.rating) : null,
            image_url: p.image_url || null,
            diet_type_id: p.diet_type_id ? Number(p.diet_type_id) : null,
            source: 'ziomap',
            status: 'APPROVED',
            place_id: p.place_id,
            details: {
              create: {
                city: p.city || (p.address?.includes('Hà Nội') ? 'Hà Nội' : p.address?.includes('Hồ Chí Minh') || p.address?.includes('TP.HCM') ? 'Hồ Chí Minh' : 'Chưa xác định'),
                hours: p.hours || 'Chưa cập nhật',
                price_range: p.price_range || 'Theo thời giá',
                separate_kitchen: p.separate_kitchen ?? null,
              },
            },
          },
        });
        saved.push(record);
      } catch (err) {
        console.warn(`[placeRepository] Bỏ qua lỗi lưu cache quán ${p.place_id}:`, err.message);
      }
    }
    return saved;
  },

  async findRestaurants(args = {}, db = prisma) {
    return db.restaurant.findMany(args);
  },

  async findById(restaurantId, db = prisma) {
    return db.restaurant.findUnique({
      where: { restaurant_id: Number(restaurantId) },
      include: {
        diet_type: true,
        details: true,
      },
    });
  },

  async create(data, db = prisma) {
    return db.restaurant.create({ data });
  },

  async update(restaurantId, data, db = prisma) {
    return db.restaurant.update({
      where: { restaurant_id: Number(restaurantId) },
      data,
    });
  },
};

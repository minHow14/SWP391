// D:/SWP391/SWP391/server/src/constants/passwordReset.js
export const PASSWORD_RESET_OTP_DIGITS = 6;
export const PASSWORD_RESET_OTP_TTL_MINUTES = 5;
export const PASSWORD_RESET_TOKEN_TTL_MINUTES = 5;
export const PASSWORD_RESET_OTP_MAX_ATTEMPTS = 5;
export const PASSWORD_RESET_OTP_RESEND_SECONDS = 60;
export const SECONDS_PER_MINUTE = 60;
export const MILLISECONDS_PER_SECOND = 1000;

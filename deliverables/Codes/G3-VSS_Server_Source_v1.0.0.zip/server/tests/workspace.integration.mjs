// D:/SWP391/SWP391/server/tests/workspace.integration.mjs
import './loadTestEnvironment.js';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import request from 'supertest';
import {PrismaClient} from '@prisma/client';
const {default:app}=await import('../src/app.js');
const db=new PrismaClient({log:[]});
const suffix=randomUUID();
const emails=[`integration-${suffix}@chayxanh.local`,`other-${suffix}@chayxanh.local`];
const password='Integration@12345';
const proposedRestaurantNames = [];
try{
  const catalog=await request(app).get('/api/workspace/catalog');assert.equal(catalog.status,200);
  const expectedRecipes=await db.recipe.count({where:{OR:[{post_id:null},{post:{status:'PUBLISHED'}}]}});
  assert.equal(catalog.body.data.recipes.length,expectedRecipes);
  assert.equal(catalog.body.data.ingredients.length,await db.ingredient.count());
  const swapCount=await db.$queryRaw`SELECT COUNT(*)::int AS count FROM ingredient_alternatives`;
  assert.equal(catalog.body.data.swaps.length,swapCount[0].count);
  assert.ok(catalog.body.data.recipes.every(r=>Array.isArray(r.ingredients)&&Array.isArray(r.compatible_diet_type_ids)));
  assert.ok(catalog.body.data.diets.some(d=>d.diet_type_id===6&&d.name.includes('Keto')));
  assert.ok(catalog.body.data.restaurants.every(p=>Array.isArray(p.reviews)));
  assert.ok(catalog.body.data.posts.every(p=>p.status==='PUBLISHED'));
  assert.ok(!JSON.stringify(catalog.body).includes('password_hash'));
  assert.equal((await request(app).get('/api/workspace/journal')).status,401);
  const register=await request(app).post('/api/auth/register').send({email:emails[0],password,full_name:'Integration Test'});assert.equal(register.status,201);
  const login=await request(app).post('/api/auth/login').send({email:emails[0],password});assert.equal(login.status,200);const token=login.body.token;
  const auth=req=>req.set('Authorization',`Bearer ${token}`);
  const me=await auth(request(app).get('/api/auth/me'));assert.equal(me.body.user.email,emails[0]);
  assert.equal((await request(app).patch('/api/auth/me').send({full_name:'Forbidden'})).status,401);
  const ingredientId=catalog.body.data.ingredients[0].ingredient_id;
  const dietId=catalog.body.data.diets[0].diet_type_id;
  const profileUpdate={full_name:'Updated Profile',health_profile:{height:172.5,weight:63,dob:'2000-03-12',gender:'Khác',health_goal:'Theo dõi sức khỏe',diet_type_id:dietId},allergy_ids:[ingredientId]};
  const savedProfile=await auth(request(app).patch('/api/auth/me')).send(profileUpdate);assert.equal(savedProfile.status,200);
  assert.equal(savedProfile.body.user.full_name,'Updated Profile');assert.equal(savedProfile.body.user.health_profile.height,172.5);
  assert.deepEqual(savedProfile.body.user.allergies.map(a=>a.ingredient_id),[ingredientId]);
  assert.ok(!JSON.stringify(savedProfile.body).includes('password_hash'));
  const reloadedProfile=await auth(request(app).get('/api/auth/me'));assert.equal(reloadedProfile.body.user.health_profile.dob.slice(0,10),'2000-03-12');
  assert.equal((await auth(request(app).patch('/api/auth/me')).send({role:1})).status,400);
  assert.equal((await auth(request(app).patch('/api/auth/me')).send({user_id:999})).status,400);
  assert.equal((await auth(request(app).patch('/api/auth/me')).send({health_profile:{dob:'2026-02-31'}})).status,400);
  assert.equal((await auth(request(app).patch('/api/auth/me')).send({health_profile:{dob:'2999-01-01'}})).status,400);
  assert.equal((await auth(request(app).patch('/api/auth/me')).send({health_profile:{diet_type_id:32000}})).status,400);
  assert.equal((await auth(request(app).patch('/api/auth/me')).send({full_name:'Must roll back',allergy_ids:[2147483647]})).status,400);
  assert.equal((await auth(request(app).get('/api/auth/me'))).body.user.full_name,'Updated Profile');
  assert.equal((await auth(request(app).patch('/api/auth/me')).send({allergy_ids:[ingredientId,ingredientId]})).status,400);
  const clearedProfile=await auth(request(app).patch('/api/auth/me')).send({health_profile:{height:null,weight:null,dob:null,gender:null,health_goal:null,diet_type_id:null},allergy_ids:[]});
  assert.equal(clearedProfile.status,200);assert.equal(clearedProfile.body.user.health_profile.height,null);assert.deepEqual(clearedProfile.body.user.allergies,[]);
  const blog=await auth(request(app).post('/api/blogs')).send({title:'Integration recipe discussion',content:`Test post ${suffix}`});assert.equal(blog.status,201);
  const postId=blog.body.blog.post_id;assert.ok(postId);
  assert.equal((await auth(request(app).put(`/api/blogs/${postId}`)).send({title:'Updated integration discussion'})).status,200);
  assert.equal((await auth(request(app).post('/api/comments')).send({post_id:postId,content:'Integration comment'})).status,201);
  assert.equal((await auth(request(app).post('/api/votes')).send({post_id:postId,vote_type:'UPVOTE'})).status,201);
  const feed=await request(app).get('/api/workspace/catalog');
  const published=feed.body.data.posts.find(p=>p.post_id===postId);
  assert.equal(published.title,'Updated integration discussion');assert.equal(published.comments.length,1);assert.equal(published.vote_count,1);
  assert.equal((await auth(request(app).delete(`/api/votes/post/${postId}`))).status,200);
  assert.equal((await auth(request(app).delete(`/api/blogs/${postId}`))).status,200);
  const afterDelete=await request(app).get('/api/workspace/catalog');assert.ok(!afterDelete.body.data.posts.some(p=>p.post_id===postId));
  assert.equal((await auth(request(app).patch('/api/workspace/profile')).send({height:168,weight:60,calorieGoal:1850,goal:'Theo dõi'})).status,200);
  const before=await auth(request(app).get('/api/workspace/journal'));assert.deepEqual(before.body.data.days,{});assert.equal(before.body.data.profile.weight,60);
  const record=await auth(request(app).post('/api/workspace/diary')).send({date:'2026-10-11',group:'SNACK',name:'Integration food',serving:'1 phần',calories:100,protein:2,carbs:10,fat:1,fiber:2});assert.equal(record.status,200);const diaryId=record.body.data.diary_id;
  const journal=await auth(request(app).get('/api/workspace/journal'));assert.equal(journal.body.data.days['2026-10-11'][0].calories,100);assert.equal(journal.body.data.days['2026-10-11'][0].protein,2);
  const other=await request(app).post('/api/auth/register').send({email:emails[1],password,full_name:'Other Integration'});assert.equal(other.status,201);
  const otherProfile=await request(app).get('/api/auth/me').set('Authorization',`Bearer ${other.body.token}`);
  assert.equal(otherProfile.body.user.full_name,'Other Integration');assert.equal(otherProfile.body.user.health_profile,null);assert.deepEqual(otherProfile.body.user.allergies,[]);
  assert.equal((await request(app).delete(`/api/workspace/diary/${diaryId}`).set('Authorization',`Bearer ${other.body.token}`)).status,404);
  assert.equal((await auth(request(app).delete(`/api/workspace/diary/${diaryId}`))).status,200);
  const recipe=catalog.body.data.recipes[0];assert.ok(recipe,'Database needs a recipe for plan integration tests');
  assert.equal((await auth(request(app).put('/api/workspace/plan')).send({date:'2026-10-12',group:'BREAKFAST',recipe_id:recipe.recipe_id})).status,200);
  assert.equal((await auth(request(app).post('/api/workspace/plan/record')).send({date:'2026-10-12'})).status,200);
  assert.equal((await auth(request(app).post('/api/workspace/plan/record')).send({date:'2026-10-12'})).status,409);
  const place=catalog.body.data.restaurants[0];
  if(place){
    const priorRating=await db.restaurant.findUnique({where:{restaurant_id:place.id},select:{rating:true}});
    try{assert.equal((await auth(request(app).post(`/api/workspace/restaurants/${place.id}/reviews`)).send({stars:4,text:`Integration review ${suffix}`})).status,200);const again=await request(app).get('/api/workspace/catalog');assert.ok(again.body.data.restaurants.find(p=>p.id===place.id).reviews.some(r=>r.text===`Integration review ${suffix}`));}finally{await db.$executeRaw`DELETE FROM restaurant_reviews WHERE content=${`Integration review ${suffix}`}`;await db.restaurant.update({where:{restaurant_id:place.id},data:priorRating});}
  }
  assert.equal((await auth(request(app).post('/api/workspace/diary')).send({date:'2026-02-31',group:'SNACK',name:'Invalid',serving:'1',calories:-1,protein:0,carbs:0,fat:0,fiber:0})).status,400);
  const photoCases = [
    { label: 'missing', input: undefined, expected: null },
    { label: 'stock', input: 'https://images.unsplash.com/photo-1540420773420-3366772f4999', expected: null },
    { label: 'local', input: '/uploads/restaurants/integration-photo.jpg', expected: '/uploads/restaurants/integration-photo.jpg' },
  ];
  for (const photoCase of photoCases) {
    const name = `Quán Chay Đề Xuất ${suffix} ${photoCase.label}`;
    proposedRestaurantNames.push(name);
    const proposedRes = await auth(request(app).post('/api/workspace/restaurants')).send({
      name, address: '100 Nguyễn Huệ, Q.1, TP.HCM', city: 'Hồ Chí Minh',
      diet_type_id: dietId, latitude: 10.7745, longitude: 106.7020, image_url: photoCase.input,
    });
    assert.equal(proposedRes.status, 200);
    const proposedId = proposedRes.body.data.restaurant_id || proposedRes.body.data.id;
    assert.ok(Number.isInteger(proposedId) && proposedId > 0);
    assert.equal(proposedRes.body.data.name, name);
    assert.equal(proposedRes.body.data.image, photoCase.expected);
    const stored = await db.restaurant.findUnique({ where: { restaurant_id: proposedId }, select: { image_url: true } });
    assert.equal(stored.image_url, photoCase.expected);
  }
  console.log('PASS: database catalog, authentication, community CRUD/comments/votes, private journals, persisted nutrition, ownership, weekly plans, review persistence and input validation.');
} finally {
  try {
    await db.$transaction([
      db.restaurant.deleteMany({ where: { name: { in: proposedRestaurantNames } } }),
      db.user.deleteMany({ where: { email: { in: emails } } }),
    ]);
  } finally { await db.$disconnect(); }
}

// client/test/restaurantDirections.test.js
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { hasCoordinates, restaurantDirections } from '../src/utils/restaurantDirections.js';

test('directions point at the named address even when coordinates exist', () => {
  const place = { name: 'Quán A', address: '123 Đường B', latitude: null, longitude: null };
  assert.equal(new URL(restaurantDirections(place)).searchParams.get('destination'), 'Quán A, 123 Đường B');
  // Tọa độ sẽ bị Google đổi thành địa điểm gần nhất, có thể là một quán khác cùng địa chỉ.
  assert.equal(new URL(restaurantDirections({ ...place, latitude: 10, longitude: 106 })).searchParams.get('destination'), 'Quán A, 123 Đường B');
});

test('directions fall back to coordinates only when the place has no address', () => {
  const url = new URL(restaurantDirections({ name: 'Quán A', address: '', latitude: 10, longitude: 106 }));
  assert.equal(url.searchParams.get('destination'), '10,106');
  assert.equal(new URL(restaurantDirections({ address: '123 Đường B' })).searchParams.get('destination'), '123 Đường B');
});

test('map and directions reject missing and out-of-range coordinates, but accept zero', () => {
  assert.equal(hasCoordinates({ latitude: 0, longitude: 0 }), true);
  for (const coordinates of [null, {}, { latitude: null, longitude: 106 }, { latitude: NaN, longitude: 106 }, { latitude: 91, longitude: 106 }, { latitude: 10, longitude: 181 }]) {
    assert.equal(hasCoordinates(coordinates), false);
  }
  assert.equal(new URL(restaurantDirections({ name: 'Quán A', address: 'Đường B', latitude: 91, longitude: 106 })).searchParams.get('destination'), 'Quán A, Đường B');
});

test('directions includes origin when user coordinates are provided', () => {
  const place = { name: 'Quán Chay A', latitude: 10.7765, longitude: 106.6918 };
  const userOrigin = { lat: 10.7500, lng: 106.6800 };
  const url = new URL(restaurantDirections(place, userOrigin));
  assert.equal(url.searchParams.get('destination'), '10.7765,106.6918');
  assert.equal(url.searchParams.get('origin'), '10.75,106.68');
});

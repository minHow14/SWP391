// client/test/nearbyPlaces.test.js
import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  CITY_HUBS,
  HCM_HUBS,
  RADIUS_OPTIONS,
  DIET_OPTIONS,
  checkIsOpenNow,
  getPosition,
  isVegetarianPlace,
  resolveRestaurantPhoto,
} from '../src/features/restaurants/utils/nearbyHelpers.js';
import { placeService } from '../src/services/placeService.js';
import apiClient from '../src/services/apiClient.js';

test('CITY_HUBS contains major Vietnam cities and valid district hubs with GPS coordinates', () => {
  assert.ok(Array.isArray(CITY_HUBS));
  assert.ok(CITY_HUBS.length >= 4);

  const cityIds = CITY_HUBS.map((c) => c.id);
  assert.ok(cityIds.includes('hcm'));
  assert.ok(cityIds.includes('hn'));
  assert.ok(cityIds.includes('dn'));

  for (const city of CITY_HUBS) {
    assert.ok(city.id && city.name);
    assert.ok(Array.isArray(city.hubs) && city.hubs.length > 0);
    for (const hub of city.hubs) {
      assert.ok(hub.id && hub.name);
      assert.ok(typeof hub.lat === 'number' && hub.lat >= -90 && hub.lat <= 90);
      assert.ok(typeof hub.lng === 'number' && hub.lng >= -180 && hub.lng <= 180);
    }
  }

  // HCM_HUBS backward compatibility export
  assert.equal(HCM_HUBS, CITY_HUBS[0].hubs);
});

test('RADIUS_OPTIONS and DIET_OPTIONS have expected values', () => {
  assert.deepEqual(RADIUS_OPTIONS, [3, 5, 10]);
  assert.ok(Array.isArray(DIET_OPTIONS));
  assert.ok(DIET_OPTIONS.some((d) => d.id === null));
  assert.ok(DIET_OPTIONS.some((d) => d.id === 1)); // Vegan
  assert.ok(DIET_OPTIONS.some((d) => d.id === 5)); // Buddhist
});

test('checkIsOpenNow parses operating hours accurately', () => {
  const midDay = new Date('2026-10-26T12:00:00+07:00');
  const earlyMorning = new Date('2026-10-26T05:00:00+07:00');
  const lateNight = new Date('2026-10-26T23:30:00+07:00');
  const pastMidnight = new Date('2026-10-26T01:30:00+07:00');

  assert.equal(checkIsOpenNow('07:00 - 21:00', midDay), true);
  assert.equal(checkIsOpenNow('07:00 - 21:00', earlyMorning), false);
  assert.equal(checkIsOpenNow('07:00 - 21:00', lateNight), false);
  assert.equal(checkIsOpenNow('18:00 - 02:00', lateNight), true);
  assert.equal(checkIsOpenNow('18:00 - 02:00', pastMidnight), true);
  assert.equal(checkIsOpenNow('18:00 - 02:00', midDay), false);
  assert.equal(checkIsOpenNow('Chưa cập nhật', midDay), null);
  assert.equal(checkIsOpenNow(null, midDay), null);
});

test('placeService.getNearbyPlaces constructs correct query params including dietTypeId and user GPS', async () => {
  let capturedUrl = '';
  let capturedOptions = null;
  const originalGet = apiClient.get;

  try {
    apiClient.get = async (url, options) => {
      capturedUrl = url;
      capturedOptions = options;
      return { success: true, data: { places: [] } };
    };

    await placeService.getNearbyPlaces({
      lat: 10.7769,
      lng: 106.7009,
      userLat: 10.7500,
      userLng: 106.6800,
      radiusKm: 5,
      limit: 15,
      dietTypeId: 1,
    });

    assert.equal(capturedUrl, '/places/nearby');
    assert.deepEqual(capturedOptions.params, {
      lat: 10.7769,
      lng: 106.7009,
      user_lat: 10.7500,
      user_lng: 106.6800,
      radius_km: 5,
      limit: 15,
      diet_type_id: 1,
    });
  } finally {
    apiClient.get = originalGet;
  }
});

test('getPosition resolves with coordinates when geolocation succeeds', async () => {
  const mockNavigator = {
    geolocation: {
      getCurrentPosition: (success) => {
        success({ coords: { latitude: 10.7769, longitude: 106.7009 } });
      },
    },
  };
  const pos = await getPosition(mockNavigator);
  assert.deepEqual(pos, { lat: 10.7769, lng: 106.7009 });
});

test('getPosition rejects with user-friendly error when permission is denied', async () => {
  const mockNavigator = {
    geolocation: {
      getCurrentPosition: (_, error) => {
        error({ code: 1 });
      },
    },
  };
  await assert.rejects(
    getPosition(mockNavigator),
    /Bạn đã từ chối quyền truy cập vị trí trên trình duyệt/
  );
});

test('getPosition rejects when geolocation is unsupported', async () => {
  await assert.rejects(
    getPosition({}),
    /Trình duyệt không hỗ trợ định vị GPS/
  );
});

test('resolveRestaurantPhoto preserves real photos and never substitutes unrelated stock photos', () => {
  const placeWithRealPhoto = { name: 'Quán Chay An Lạc', image_url: 'https://my-real-restaurant.com/photo.jpg' };
  assert.equal(resolveRestaurantPhoto(placeWithRealPhoto), 'https://my-real-restaurant.com/photo.jpg');
  assert.equal(resolveRestaurantPhoto({ image: '/uploads/restaurants/verified.jpg' }), '/uploads/restaurants/verified.jpg');
  for (const image of [null, '', 'places/place/photos/photo', 'javascript:alert(1)',
    'https://images.unsplash.com/photo-1540420773420-3366772f4999', '/demo-assets/image.jpg']) {
    assert.equal(resolveRestaurantPhoto({ name: 'Quán kiểm thử', image }), null);
  }
  assert.equal(resolveRestaurantPhoto(null), null);
});

test('isVegetarianPlace identifies true vegetarian places and rejects non-vegetarian names', () => {
  // Accepted
  assert.equal(isVegetarianPlace({ name: 'Nhà Hàng Chay Hum Vegetarian' }), true);
  assert.equal(isVegetarianPlace({ name: 'Siêu Thị Thực Phẩm Chay Âu Lạc' }), true);
  assert.equal(isVegetarianPlace({ name: 'Quán Chay Bồ Đề' }), true);
  assert.equal(isVegetarianPlace({ name: 'CHAY GARDEN Nguyễn Thị Minh Khai - Vegetarian Restaurant & Space' }), true);
  assert.equal(isVegetarianPlace({ name: 'Cửa Hàng Thực Dưỡng', isIngredientShop: true }), true);
  assert.equal(isVegetarianPlace({ name: 'Tiệm Ăn Chay', diet_type_id: 1 }), true);
  assert.equal(isVegetarianPlace({ name: 'Bếp Nhà', type: 'vegan' }), true);

  // Rejected: Nail & Beauty
  assert.equal(isVegetarianPlace({ name: 'UK MANI NAIL BAR' }), false);
  assert.equal(isVegetarianPlace({ name: 'Nhà Nàng Nails & Beauty - Bình Thạnh' }), false);
  assert.equal(isVegetarianPlace({ name: 'OnOn Nails Bar - Bến Thành' }), false);

  // Rejected: Spa & Massage & Chuông xoay
  assert.equal(isVegetarianPlace({ name: 'Mani Mani Spa – Massage – マッサージ – 按摩 – 마사지' }), false);
  assert.equal(isVegetarianPlace({ name: 'ANNE SPA - Nails - Gội đầu - Foot Massage' }), false);
  assert.equal(isVegetarianPlace({ name: 'Mani House - Ngôi Nhà Chuông Xoay' }), false);

  // Rejected: Yoga & Fitness
  assert.equal(isVegetarianPlace({ name: 'OM YOGA - YOGA BÌNH THẠNH' }), false);
  assert.equal(isVegetarianPlace({ name: 'Mani om yoga' }), false);

  // Rejected: Beef, Thai, Meat, Tea
  assert.equal(isVegetarianPlace({ name: 'Ushi Mania - Japanese Aging Beef & Bar' }), false);
  assert.equal(isVegetarianPlace({ name: 'Bánh Mì Chim Chạy Nguyễn Gia Trí' }), false);
  assert.equal(isVegetarianPlace({ name: 'GÓC THÁI | QUÁN THÁI NGON BÌNH THẠNH | MÓN THÁI BÌNH THẠNH' }), false);
  assert.equal(isVegetarianPlace({ name: 'CHAGEE NGUYỄN GIA TRÍ' }), false);

  // Rejected: Pure house number addresses
  assert.equal(isVegetarianPlace({ name: '36/59 nguyễn gia trí', address: '36/59 Nguyễn Gia Trí' }), false);
  assert.equal(isVegetarianPlace({ name: '69/1/7, Nguyễn Gia Trí' }), false);
});
